import axios from "axios";
import { useState } from "react";

const ResetPassword = () => {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:5000/api/reset-password",
        { email }
      );
      setMessage(response.data.msg);
    } catch (err) {
      setMessage("An error occurred. Please try again later.");
    }
  };

  return (
    <div>
      <h1>Reset Password</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Email:
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </label>

        <button type="submit">Reset password</button>
        {message && <p>{message}</p>}
      </form>
      {message && <p>{message}</p>}
    </div>
  );
};

export default ResetPassword;
