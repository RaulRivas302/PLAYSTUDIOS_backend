Navigate to the project directory:
cd your-project
Install the dependencies:
npm install

Set up environment variables:
Create a .env file in the root directory.

Define the following environment variables in the .env file:
DB_CONNECTION=your_mongodb_connection_string
JWT_SECRET=your_jwt_secret
RESET_PASSWORD_SECRET=your_reset_password_secret
MAILGUN_API_KEY=your_mailgun_api_key
MAILGUN_DOMAIN=your_mailgun_domain

Start the development server:
npm run dev
Open your browser and navigate to http://localhost:3000 to access the application.


Folder Structure
The project follows a standard folder structure for a Next.js application:

pages: Contains the Next.js pages and API routes.
src: Contains the React components, styles, and other client-side files.
server.js: The entry point for the Node.js/Express server.